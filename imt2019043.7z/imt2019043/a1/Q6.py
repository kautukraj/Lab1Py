a = 990
l = 140
v = 1100
each = (a+l+v) / 3
print ("Abhiraj's due =", round(each - a, 2))
print ("Leon's due =", round(each - l,2))
print ("Vigyan's due=", round(each - v,2))
